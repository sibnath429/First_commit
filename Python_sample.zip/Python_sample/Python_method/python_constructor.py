"""the Python constructor is a method that is called when an object is created. This method is defined in the class
and can be used to initialize basic variables. This class is called each time we create a new object. For example,
if we create four objects, the class constructor will be called four times. Every class has a constructor,
but it is not required to explicitly define it. The simple syntax of the Python constructor looks like this:
object is like a token
 the method __init__()simulates the constructor of the class. This method is called when the class is instantiated.
 It accepts the self-keyword as a first argument which allows accessing the attributes or method of the class.

  Python non-parameterized constructor The constructors that have an empty parameter are known as non-parameterized
  constructors. They are used to initialize the object with default values or certain specific constants depending
  upon the user. The non-parameterized constructor uses when we do not want to manipulate the value or the
  constructor that has only self as an argument.

  """

"""Notice that we did not call the __init__() method but still it was executed because the constructor executes each 
 time an object is created. """


# python class
class Student:
    # creating Python constructor
    def __init__(self):
        print("This is python constructor without arguments!!")


# creating object of type Student
student = Student()

"""Python parameterized constructor The constructor with parameters is known as parameterized constructor. The 
parameterized constructor takes its first argument as a reference to the instance being constructed known as self and 
the rest of the arguments are provided by the programmer. The simple syntax of the Python parameterized constructor 
is as follows: """


# python class
class Teacher:
    # creating Python constructor
    def __init__(self, total_marks, obtain_marks):
        self.total_marks = total_marks
        self.obtain_marks = obtain_marks

    def marks(self):
        # printing
        print("Total marks are : ", self.total_marks)
        print("Obtain marks are :", self.obtain_marks)


# creating object of type Student
teacher = Teacher(100, 84)
# calling marks method
teacher.marks()
