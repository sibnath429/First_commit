"""Multiple Python constructors in a single class We have already learned a lot about the Python constructor and
understood it through various examples. But what if we try declaring more than one similar constructor in the Class.
See the example below, where we had declared two constructors in a single Python class.
"""


# python class
class Student:
    # creating Python constructor 1
    def __init__(self):
        # printing
        print("this is the first constructor!")

    # python constructor 2
    def __init__(self):
        # printing
        print("this is the second constructor!")


# creating object of type Student
student1 = Student()

"""In the above Python program, we have defined a class and declared two constructors with the same configuration. We 
have then created the object called student, but it cannot access the first method. Internally, the class object will 
always call the last constructor if the class has more than one constructor. """
