"""
In Object-oriented programming, when we design a class, we use the following three methods:

Instance_method: Instance method performs a set of actions on the data/value provided by the instance variables.
If we use instance variables inside a method, such methods are called instance methods.
The instance method can access both class level and object attributes. Therefore, It can modify the object state.
Use self as the first parameter in the instance method when defining it.
The self parameter refers to the current object.

class_method: The class method in Python is a method, which is bound to the class but not the object of that class.
Class method is method that is called on the class itself, not on a specific object instance.
Therefore, it belongs to a class level, and all class instances share a class method.
Use the @classmethod decorator or the classmethod() function to define the class method.
On the other hand, Use cls as the first parameter in the class method when defining it. The cls refers to the class.

Static method: is a general utility method that performs a task in isolation.
This method doesn’t have access to the instance and class variable.
Use the @staticmethod decorator or the staticmethod() function to define a static method.
A static method doesn’t take instance or class as a parameter
because they don’t have access to the instance variables and class variables.
"""


class Student:
    # class variables
    school_name = 'ABC School'

    def __init__(self, name, age):
        self.name = name
        self.age = age

    # instance method
    def show(self):
        # access instance variables
        print('Student:', self.name, self.age)
        # access class variables
        print('School:', self.school_name)

    @classmethod
    def change_School(cls, name):
        # access class variable
        print('Previous School name:', cls.school_name)
        cls.school_name = name
        print('School name changed to', cls.school_name)
        print('School name changed to', Student.school_name)

    @staticmethod
    def find_notes(subject_name):
        # can't access instance or class attributes
        return ['chapter 1', 'chapter 2', 'chapter 3']


# create object
jessa = Student('Jessa', 12)
# call instance method
jessa.show()

# call class method
Student.change_School('XYZ School')
