"""
Dictionaries are used to store data values in key:value pairs.
A dictionary is a collection which is ordered*, changeable and do not allow duplicates.
Dictionaries are written with curly brackets, and have keys and values:

# initialize dictionary
emptyDict = dict()

# {} symbol to initialize dictionary
emptyDict = {}
"""

"""Python dictionaries were unordered but after Python 3.7 version Dictionaries are ordered. It preserves the order 
of insertion, i.e., while creating a dictionary with key-value pairs, each key-value pair will be inserted in the 
order it has been defined one after another. But previously, the elements of the dictionary were inserted in 
alphabetical order. """


"""Can a dictionary have duplicate keys in Python? No, Python does not allow duplicate keys into a dictionary. Keys 
in python are used as unique identifiers. Duplicate keys thus might lead to ambiguity. If you try to add a key value 
pair, but the key already exists, Python will simply update the value of the key in dictionary with the new value. """
# For example,
#
# Python Version 2.x ( When dictionaries were unordered)

dict1={ 3: 'Three', 7: 'Seven', 1: 'One',2: 'Two'}

print(dict1)

# Output:
#
# {1:’One’ , 2: Two’, 3: Three’, 7: ‘Seven’}

# Python 3.7 and above: ( When dictionaries are ordered)

dict1={ 3: 'Three',  7: 'Seven', 1: 'One', 2: 'Two'}

print(dict1)
#
# Output:
#
# { 3: ‘Three’, 7: ‘Seven’, 1: ‘One’ ,’2: Two’}

"""
Dictionary methods
clear() – Remove all the elements from the dictionary
copy() – Returns a copy of the dictionary
get() – Returns the value of specified key
items() – Returns a list containing a tuple for each key value pair
keys() – Returns a list containing dictionary’s keys
pop() – Remove the element with specified key
popitem() – Removes the last inserted key-value pair
update() – Updates dictionary with specified key-value pairs
values() – Returns a list of all the values of dictionary
"""

