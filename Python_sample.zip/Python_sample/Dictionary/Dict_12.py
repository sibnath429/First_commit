"""How to Check if Python Dictionary is Empty?"""

myDict = {}
if (len(myDict) == 0):
    print('The dictionary is empty.')
else:
    print('The dictionary is not empty.')