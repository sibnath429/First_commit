"""Write a Python script to concatenate following dictionaries to create a new one"""

dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}

"""Using update"""
dic1.update(dic2)
print('Updated dictionary:')
print(dic1)

"""Using ** operator"""
"""The simplest way to merge two dictionaries in python is by using the unpack operator(**)."""

dict4 = {**dic1,**dic2,**dic3}
print('Updated dictionary:')
print(dict4)





