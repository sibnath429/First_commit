"""Write a Python program to get the maximum and minimum value in a dictionary."""

my_dict = {'x':500, 'y':5874, 'z': 560}

print("Maximum value is : {}".format(max(my_dict.values())))

