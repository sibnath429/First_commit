dict_n={'A':100,'B':540,'C':239}

res = {v:k for k,v in dict_n.items()}
#res = dict((v,k) for k,v in dict_n.items())
print(res)