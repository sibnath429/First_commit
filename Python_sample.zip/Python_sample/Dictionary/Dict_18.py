"""Write a Python program to convert given a dictionary to a list of tuples."""

"""
Original Dictionary:
{'Red': 1, 'Green': 3, 'White': 5, 'Black': 2, 'Pink': 4}

Convert the said dictionary to a list of tuples:
[('Red', 1), ('Green', 3), ('White', 5), ('Black', 2), ('Pink', 4)]

"""

original_dict = {'Red': 1, 'Green': 3, 'White': 5, 'Black': 2, 'Pink': 4}

result = list(map(tuple,original_dict.items()))

print("Converted the said dictionary to a list of tuples: {} ".format(result))






