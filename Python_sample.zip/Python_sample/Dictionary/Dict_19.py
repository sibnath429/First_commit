"""Swap value and key in dict"""

students = {'Theodore': 10, 'Mathew': 11, 'Roxanne': 9}

result = {val: key for key, val in students.items()}

print("After swapping the key & value : {}".format(result))
