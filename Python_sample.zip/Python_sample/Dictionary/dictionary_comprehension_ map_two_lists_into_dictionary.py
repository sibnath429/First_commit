#dictionary comprehension
items = ['pen', 'paper', 'pencil']
quantities = [5, 20, 15]
item_quantities = zip(items, quantities)
items_dict = {key:value for key, value in item_quantities}

print(items_dict)