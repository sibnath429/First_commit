"""Write a Python script to generate and print a dictionary that contains a number (between 1 and n) in the form (x,
x*x). """

dict = {}
n = int(input("Enter the no:"))
for d in range(1,n+1):
    dict[d] = d*d
print(dict)