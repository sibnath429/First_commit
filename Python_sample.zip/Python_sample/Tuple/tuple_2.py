"""Write a Python program to create a tuple with different data types"""

#Create a tuple with different data types
tuplex = ("tuple", False, 3.2, 1)
print(tuplex)
