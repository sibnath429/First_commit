"""Write a Python program to find the length of a tuple"""

#create a tuple
tuplex = tuple("w3resource")
print(tuplex)
#use the len() function to known the length of tuple
print(len(tuplex))