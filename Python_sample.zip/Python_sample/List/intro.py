
greeting = 'Hello'
name = 'Michael'

print(help(str.lower))
