# program to convert string to integer list
# language: python3

# declare a list
str1 = "12345"

# list variable to integeres


list = list(str1)


# printing the str_list and int_list
print ("str1: ", str1)
print ("int_list: ", list)