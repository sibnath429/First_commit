# Python program to clone or copy list using slicing

# Getting list from user
myList = []
length = int(input("Enter number of elements : "))
for i in range(0, length):
    value = int(input())
    myList.append(value)

# cloning the list
copyList = myList[:]

# Printing lists
print("Entered List ", myList)
print("Cloned List ", copyList)