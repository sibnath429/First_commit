# Getting list from user
myList = []
length = int(input("Enter number of elements: "))
for i in range(0, length):
    value = int(input())
    myList.append(value)

print(myList)

positive = []
negetive = []
for ele in myList:
    if ele >= 0:
        positive.append(ele)
    else:
        negetive.append(ele)

print("positive List", positive)
print("negetive List", negetive)



