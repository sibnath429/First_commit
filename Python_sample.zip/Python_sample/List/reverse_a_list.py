li = [21,1,3,4,5,6,7,8,9,19,34,36,48,50,51]

def rev(l):
  return l[::-1]

rev(li)
print(rev(li))