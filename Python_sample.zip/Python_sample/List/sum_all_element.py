# calculating Sum of all elements
list = [10, 20, 30, 40, 50]
sum = 0
for L in list:
	sum += L
print ("Sum is: ", sum)