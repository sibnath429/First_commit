# Python program to clone or copy list
# using extend() method

# Getting list from user
myList = []
length = int(input("Enter number of elements : "))
for i in range(0, length):
    value = int(input())
    myList.append(value)

# cloning the list
copyList = []
copyList.extend(myList)

# Printing lists
print("Entered List ", myList)
print("Copy List ", copyList)