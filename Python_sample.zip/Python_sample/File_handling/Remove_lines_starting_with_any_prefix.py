# import os
#
# file2 = open('GFG_updated.txt', 'w')
# FILE_NAME_NORMAL = 'GFG.txt'
# os.path.join(os.path.dirname(os.path.abspath(__file__)), FILE_NAME_NORMAL)
# with open('GFG.txt', 'r') as file:
#     # reading each line
#     for line in file:
#         if not line.startswith("sibnath"):
#             print(line)
#             # storing only those lines that
#             # do not begin with "sibnath"
#             file2.write(line)
#
# file2.close()

"""***************************************Using findall method*****************************************"""
import os
import re
file2 = open('GFG_updated_usingfindall.txt', 'w')
FILE_NAME_NORMAL = 'GFG.txt'
os.path.join(os.path.dirname(os.path.abspath(__file__)), FILE_NAME_NORMAL)
with open('GFG.txt', 'r') as file:
    # reading each line from original
    # text file
    for line in file.readlines():
        # reading all lines that begin
        # with "TextGenerator"
        result = re.findall("^sibnath",line)
        if not result:
            print(line)
            # storing only those lines that
            # do not begin with "sibnath"
            file2.write(line)

file2.close()





"""***************************************Using findall method*****************************************"""

# defining object file1 to
# open GeeksforGeeks file in
# read mode
file1 = open('GeeksforGeeks.txt',
             'r')

# defining object file2 to
# open GeeksforGeeksUpdated file
# in write mode
file2 = open('GeeksforGeeksUpdated.txt',
             'w')

# reading each line from original
# text file
for line in file1.readlines():

    # reading all lines that do not
    # begin with "TextGenerator"
    if not (line.find('TextGenerator') == 0):
        # printing those lines
        print(line)

        # storing only those lines that
        # do not begin with "TextGenerator"
        file2.write(line)

# close and save the files
file2.close()
file1.close()
