"""In Python, a nested dictionary is a dictionary inside a dictionary. It's a collection of dictionaries into one
single dictionary.

nested_dict = { 'dictA': {'key_1': 'value_1'}, 'dictB': {'key_2': 'value_2'}} Here, the nested_dict is a nested
dictionary with the dictionary dictA and dictB. They are two dictionary each having own key and value.

"""

"""To access element of a nested dictionary, we use indexing [] syntax in Python."""

people = {1: {'name': 'John', 'age': '27', 'sex': 'Male'},
          2: {'name': 'Marie', 'age': '22', 'sex': 'Female'}}

print(people[1]['name'])
print(people[1]['age'])
print(people[1]['sex'])


