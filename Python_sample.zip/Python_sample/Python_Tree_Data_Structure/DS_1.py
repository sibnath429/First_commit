"""Tree Data structure in Python"""
"""A Tree is a non linear data structure in which nodes are connected in a hierarchical manner. Every tree has one 
root node that marks the access point of all the other nodes in the tree. So, a Tree is formed of one root node, 
and 0 or more child nodes. The trees are categorized into different types on the basis of their structure and type of 
data. They are Binary Tree, Binary Search Tree, AVL Tree, B Tree, B+ Tree, Expression Tree, etc. """


