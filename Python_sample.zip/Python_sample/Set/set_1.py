"""
Set is one of 4 built-in data types in Python used to store collections of data
Sets are used to store multiple items in a single variable.
A set is a collection which is unordered, unchangeable*, and unindexed.

set1 = {"abc", 34, True, 40, "male"}
Sets can be created by using the built-in set() function

Duplicates Not Allowed
Sets cannot have two items with the same value.

Example of Mutable Objects
List
Dictionary
Set

int
float
String
Tuple
Frozen Set

"""

# Python program to demonstrate
# Creation of Set in Python

# Creating a Set
set1 = set()
print("Initial blank Set:{}".format(set1))

# Creating a Set with
# the use of a String
set1 = set("GeeksForGeeks")
print("Set with the use of String: {}".format(set1))

# Creating a Set with
# the use of Constructor
# (Using object to Store String)
String = 'GeeksForGeeks'
set1 = set(String)
print("Set with the use of an Object: {}".format(set1))

# Creating a Set with
# the use of a List
set1 = set(["Geeks", "For", "Geeks"])
print("Set with the use of List: {}".format(set1))

