"""Python frozenset() Method creates an immutable Set object from an iterable."""

# Create a set
setn = {5, 10, 3, 15, 2, 20}
print("Original set elements: {}".format(setn))
print(type(setn))
print("\nMaximum value of the said set:")
print(max(setn))
print("\nMinimum value of the said set:")
print(min(setn))
