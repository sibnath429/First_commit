"""
Python has built-in XML parsing capabilities that you can access via its xml module. In this article, we will be focusing on two of the xml module’s sub-modules:

minidom
ElementTree

"""

import xml.etree.ElementTree as ET

my_tree = ET.parse("food_menu.xml")
my_root = my_tree.getroot()
print(my_root.tag)  # print root tag
print(my_root[0].tag)  # first child of root element
print(my_root[0].attrib)  # first child of root element

"""Printing all attributes of first child of root elements"""

# for ele in my_root[0]:
#     print(ele.tag,ele.attrib)


for ele in my_root.findall('food'):
    food_name = ele.find("name").text
    food_price = ele.find("price").text
    print("price of {} is {}".format(food_name,food_price))

