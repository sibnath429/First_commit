a=12
b=12
c=2022
print(a,b,c,end="-")
