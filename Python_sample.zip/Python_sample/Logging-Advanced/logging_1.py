"""Logging is a means of tracking events that happen when some software runs. Logging is important for software
developing, debugging, and running. If you don’t have any logging record and your program crashes, there are very few
chances that you detect the cause of the problem. And if you detect the cause, it will consume a lot of time.
basicConfig(**kwargs): method used to config the logging system: by default level is : Warning
"""
import logging
# Create and configure logger
logging.basicConfig(filename="logFile.log", level=logging.DEBUG, format='%(asctime)s %(message)s', filemode='w')
# Creating an object
logger = logging.getLogger()
# Setting the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG)
# Test messages
logger.debug("Harmless debug Message")
logger.info("Just an information")
logger.warning("Its a Warning")
logger.error("Did you try to divide by zero")
logger.critical("Internet is down")