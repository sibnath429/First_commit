# Python program to check if a string
# contains any special character

import re

# Getting string input from the user
myStr =  input('Enter the string : ')

# Checking if a string contains any special character
regularExp = re.compile('[@_!#$%^&*()<>?/\|}{~:]')

# Printing values
print("Entered String is ", myStr)
if(regularExp.search(myStr) == None):
    print("The string does not contain special character(s)")
else:
    print("The string contains special character(s)")