# count vowels in a string

# declare, assign string
str = "Hello world, i'm sibnath"

list = list(str)

vowels = ['a','e','i','o','u','A','E','I','O','U']

new_list = []
for ele in list:
    if ele in vowels:
        new_list.append(ele)

print(len(new_list))