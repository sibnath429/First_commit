str1 = "learn programming at includehelp"
str2 = "learn python programming language"

# done by me

fist_list = str1.split( )
second_list = str2.split( )
print("fist_list :",fist_list)
print("second_list :",second_list)

uncommon_list = []
for ele in fist_list:
    if ele not in second_list:
        uncommon_list.append(ele)
for ele in second_list:
    if ele not in fist_list:
        uncommon_list.append(ele)

print("uncommon list :",uncommon_list)


