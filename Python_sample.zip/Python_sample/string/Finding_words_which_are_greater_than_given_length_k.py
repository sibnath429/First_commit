# Python program to find words which are greater
# than given length k

# Getting input from user
myStr =  input('Enter the string : ')
k = int(input('Enter k  (value for accepting string) : '))

list = myStr.split()


for ele in list:
    if len(ele) > k:
        print("{} this element's length is greter than k".format(ele))

    else:
        print("{} this element's length is less than k".format(ele))