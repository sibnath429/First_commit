# Input :
# abba
# Output :
# Valid