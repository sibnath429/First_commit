"""Input: String: "geeks for geeks makes learning fun"
       Substring: "geeks"
Output: True
Input: String: "geeks for geeks makes learning fun"
       Substring: "makes"
Output: False"""

# import library
import re

# list of different types of file
String = "geeks for geeks makes learning fun"
Substring = "geeks"

if Substring in String:
    # search given pattern in the line
    match = re.search("^" + Substring , String) # ^ represent start with

    # if match is found
    if match:
        print("The str starts with :", Substring)
