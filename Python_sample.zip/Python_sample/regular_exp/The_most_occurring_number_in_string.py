"""

Input :geek55of55geeks4abc3dr2
Output :55

Input :abcd1def2high2bnasvd3vjhd44
Output :2

"""

# import module for regular expression and collections
import re
import collections

string='ABC12ED13we14'

number = re.findall(r"[0-9]", string)

counter = collections.Counter(number)
max_count = 0
max_value = None
for key in list(counter.keys()):
  if(counter[key]>max_count):
    max_count = counter[key]
    max_value = int(key)
print("max_value",max_value)

