# Input: 'HelloWorldOfPython'
#
# Output: Hello World Of Python
#
# Input: 'LetUsStudyPython'
#
# Output: Let Us Study Python

# import module for regular expression
import re
#input
string='HelloWorldOfPython'
#Find the words in string starting with uppercase letter.
words = re.findall('[A-Z][a-z]*', string) #store as a list format
#concatenate the word with space
print(' '.join((words))) # converted to string


