"""This program searches for the files having “.xml” extension from a list of different files.
Make a regular expression/pattern : “\.xml$”
Here re.search() function is used to check for a match anywhere in the string (name of the file). It basically returns the match object when the pattern is found and if the pattern is not found it returns null.
The functionality of different Metacharacters used here:
\ It is used to specify a special meaning of character after it. It is also used to escape special characters.
 $ The string ends with the pattern which is before it."""

# import library
import re

# list of different types of file
filenames = ["gfg.html", "geeks.xml",
             "computer.txt", "geeksforgeeks.jpg"]

for file in filenames:
    # search given pattern in the line
    match = re.search("\.xml$", file)

    # if match is found
    if match:
        print("The file ending with .xml is:", file)
