import re

with open('GFG.txt', 'r') as file:
    fi = file.readlines()


re_ip = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")


for line in fi:
    ip = re.findall(re_ip,line)
    if ip:
        print("IP is {}".format(ip))


