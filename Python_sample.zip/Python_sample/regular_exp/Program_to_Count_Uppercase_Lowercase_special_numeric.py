import re

string = "ThisIsGeeksforGeeks !, 123"

# Creating separate lists using
# the re.findall() method.
uppercase_characters = re.findall(r"[A-Z]", string)
lowercase_characters = re.findall(r"[a-z]", string)
numerical_characters = re.findall(r"[0-9]", string)
special_characters = re.findall(r"[, .!?]", string)

print("The no. of uppercase characters is {} and the characters are {} ".format(len(uppercase_characters),uppercase_characters))
print("The no. of lowercase characters is {} and the characters are {} ".format(len(lowercase_characters),lowercase_characters))
print("The no. of numerical characters is {} and the characters are {} ".format(len(numerical_characters),numerical_characters))
print("The no. of special characters is {} and the characters are {} ".format(len(special_characters),special_characters))
