# Input: str = “Good bye bye world world”
# Output: Good bye world


str = "Good bye bye world world"
word = str.split()
modified_list = []
for i in word:
    if not i in modified_list:
        modified_list.append(i)
final_str = ' '.join(modified_list)
print(final_str)

