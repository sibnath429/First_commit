"""
Python – Check if String Contain Only Defined Characters using Regex

Input: ‘657’ let us say regular expression contain following characters-
(‘78653’)
Output: Valid Explanation
"""

import re

# _driver code
pattern = re.compile('^[1234]+$')
strng = "2314"
# _matching the strings
if re.search(pattern, strng):
    print("Valid String")
else:
    print("Invalid String")




