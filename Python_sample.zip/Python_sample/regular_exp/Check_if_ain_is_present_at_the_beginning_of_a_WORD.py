import re

txt = "The rain in Spain"

#Check if "ain" is present at the beginning of a WORD:

x = re.findall(r"\brai", txt)

print(x)

if x:
  print("Yes, there is at least one match!")
else:
  print("No match")