"""
A thread is simply a subset of a process!
Multithreading is defined as the ability of a processor to execute multiple threads concurrently.
"""

"""Multithreading is a threading technique in Python programming to run multiple threads concurrently by rapidly 
switching between threads with a CPU help (called context switching). Besides, it allows sharing of its data space 
with the main threads inside a process that share information and communication with other threads easier than 
individual processes. Multithreading aims to perform multiple tasks simultaneously, which increases performance, 
speed and improves the rendering of the application. """

# Python program to illustrate the concept
# of threading
# importing the threading module
import threading


def print_cube(num):
    while (True):
        # function to print cube of given num
        print("Cube: {}".format(num * num * num))


def print_square(num):
    while (True):
        # function to print square of given num
        print("Square: {}".format(num * num))


if __name__ == "__main__":
    # creating thread
    t1 = threading.Thread(target=print_square, args=(10,))
    t2 = threading.Thread(target=print_cube, args=(10,))

    # starting thread
    t1.start()
    # starting thread 2
    t2.start()

    # wait until thread 1 is completely executed
    t1.join()
    # wait until thread 2 is completely executed
    t2.join()

    # both threads completely executed
    print("Done!")

"""To create a new thread, we create an object of Thread class. It takes following arguments:
     target: the function to be executed by thread
     args: the arguments to be passed to the target function
     To start a thread, we use start method of Thread class."""

"""On invoking the join() method:
   the calling thread (main thread) gets blocked until the thread object (on which the thread is called) gets terminated."""

"""
The threading module exposes all the methods of the thread module and provides some additional methods −

threading.activeCount() − Returns the number of thread objects that are active.
threading.currentThread() − Returns the number of thread objects in the caller's thread control.
threading.enumerate() − Returns a list of all thread objects that are currently active.
In addition to the methods, the threading module has the Thread class that implements threading. 
The methods provided by the Thread class are as follows −

run()  − The run() method is the entry point for a thread.
start()  − The start() method starts a thread by calling the run method.
join([time])  − The join() waits for threads to terminate.
isAlive()  − The isAlive() method checks whether a thread is still executing.
getName()  − The getName() method returns the name of a thread.
setName()  − The setName() method sets the name of a thread.

"""
