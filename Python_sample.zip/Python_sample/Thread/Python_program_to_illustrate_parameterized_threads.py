import threading
import time

def ProcessOne(*param):
    while(True):
        print(param[0],threading.current_thread().getName(),"is Running",param[1])
        time.sleep(param[2])

def ProcessTwo(*param):
    while(True):
        print(param[0],threading.current_thread().getName(),"is Running",param[1])
        time.sleep(param[2])

T1=threading.Thread(target=ProcessOne,name="Swift",args=('Maruti',200,1))
T2=threading.Thread(target=ProcessTwo,name='I20',args=('Hyundai',220,5))

T1.start()
T2.start()