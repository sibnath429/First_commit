import os
name = os.name
print("os name {}".format(name))

"""it is getting operation system's environment variables"""
env_var = os.environ
print("Print env variable {}".format(env_var))

"""This method returns the location of the current working directory (CWD)"""
curr_dir = os.getcwd()
print("get current working dir {}".format(curr_dir))

"""This would print all the files and directories"""
ret_val = os.listdir("C:\\")
print("Print all the files and directories {}".format(ret_val))

"""This would change the directory,It is used for changing the CWD"""
path = "C:\IPU"
ch_dir = os.chdir(path)
print("Change the directory {}".format(ch_dir))







