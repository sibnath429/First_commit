import os
"""This method creates a new directory according to the specified path. In case the specified directory already exists a FileExistsError is raised."""

path = "C:\\newpath"
new_path = os.mkdir(path)
print("Created new path")

"""
This method creates a directory recursively. It means that while creating a leaf directory if any of the intermediate level directories specified in the path is missing then the method creates them all."""
# os.makedirs()

"""This method deletes a file path. It cannot delete a directory. In case the specified path is that of a directory then the OSError is raised"""
os.remove("c:\\test.txt")
print("*******************")


"""This method is used for deleting an empty directory. If the path does not correspond to an empty directory then OSError is raised."""
# os.rmdir()

"""os.walk returns a generator that creates a tuple of values (dirpath, dirnames, filenames)"""

import os
for path, dirnames, filenames in os.walk('c:\\'):
    print('{} {} {}'.format(repr(path), repr(dirnames), repr(filenames)))

"""This method joins various path components with exactly one directory separator (“/”)"""

# Path
path = "/home"

# Join various path components
print(os.path.join(path, "User/Desktop", "file.txt"))


"""os.path.basename() method in Python is used to get the base name in specified path."""

path = '/home/User/Documents'

# Above specified path
# will be splitted into
# (head, tail) pair as
# ('/home/User', 'Documents')

# Get the base name
# of the specified path
basename = os.path.basename(path)
print(basename) #Documents

"""os.path.split() method in Python is used to Split the path name into a pair head and tail."""
# path
path = '/home/User/Desktop/'

# Split the path in
# head and tail pair
head_tail = os.path.split(path)

# print head and tail
# of the specified path
print("Head of '% s:'" % path, head_tail[0])
print("Tail of '% s:'" % path, head_tail[1], "\n")

"""
For example:

     path                             head                 tail
'/home/user/Desktop/file.txt'   '/home/user/Desktop/'   'file.txt'
'/home/user/Desktop/'           '/home/user/Desktop/'    {empty}
'file.txt'                           {empty}            'file.txt'
"""






