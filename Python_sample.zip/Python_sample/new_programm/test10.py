"""
Sample Input : "Chiranjeet Singh"
Sample Output : {'C': 1, 'h': 2, 'i': 2, 'r': 1, 'a': 1, 'n': 2, 'j': 1, 'e': 2, 't': 1, ' ': 1, 'S': 1, 'g': 1}
The function should also be case sensitive, so that a string 'AAAaaa' returns 'A3a3'.
"""
string = "ChiranjeEt Singh"
convert_into_list = list(string)
print(convert_into_list)
empty_dic = {}

for items in convert_into_list:
    if items in empty_dic:
        empty_dic[items] += 1
    else:
        empty_dic[items] = 1
print(empty_dic)

