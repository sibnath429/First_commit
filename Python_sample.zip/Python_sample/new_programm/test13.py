"""
PROBLEM:
Given a string, determine if it is comprised of all unique characters. For example,
the string 'abcde' has all unique characters and should return True.
The string 'aabcde' contains duplicate characters and should return false.

🔸Input:
str='abcde'

🔸Output:
True
"""
str = 'abcdee'

convert_to_list = list(str)

empty_list = []

for temp in convert_to_list:
    if temp not in empty_list:
        empty_list.append(temp)
    else:
        print("Contains duplicate value {}".format(temp))
