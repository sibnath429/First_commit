"""Write a Python program to find the length of a given list of non-empty strings."""


def func(strs):
    return list(map(len, strs))


strs = ['cat', 'car', 'fear', 'center']
print("Original strings:")
print(strs)
print("Lengths of the said list of non-empty strings:")
print(func(strs))
