"""
Example input :"AC*wevg12we#gh6R7as456oi96_sdf"
Example output :[12,6,7,456,96]
"""

var = ""
str = "AC*wevg12we#gh6R7as456oi96_sdf"
data_list = []
for temp in str:
    if temp.isdigit():
        var = var + temp
        data_list.append(var)
        var = ""
print(data_list)
