"""
PROBLEM:
This interview question requires you to reverse a string using recursion. Make sure to think of the base case here.
Again, make sure you use recursion to accomplish this.

⛔Note : Do not slice (e.g. string[::-1]) or use iteration, there muse be a recursive call for the function.

🔸Input:
word="Hello"

🔸Output:
olleH
"""


# Python program to reverse a string using recursion

# Function to print reverse of the passed string
def reverse(string):
    if len(string) == 0:
        return

    temp = string[0]
    reverse(string[1:])
    print(temp, end='')


# Driver program to test above function
string = "Geeks for Geeks"
reverse(string)


