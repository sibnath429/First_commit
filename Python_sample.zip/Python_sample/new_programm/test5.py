"""Write a Python program to check, for each string in a given list, whether the last character is an isolated letter
or not. Return True otherwise False. """

strs = ['ca t', 'car', 'fea r', 'cente r']
print("Original strings:")
print(strs)

empty_list = []
for s in strs:
    if len(s.split(" ")[-1]) == 1:
        empty_list.append(s)
print(empty_list)
