"""
# Python program to check if a string
# contains any special character

"""
import re

myStr = input('Enter the string : ')
print("Entered String is ", myStr)
if re.search('[@_!#$%^&*()<>?/\|}{~:]', myStr) is None:
    print("The string does not contain special character(s)")
else:
    print("The string contains special character(s)")
