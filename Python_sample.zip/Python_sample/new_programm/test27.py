"""
Find student having second largest marks.
"""

my_list = [['Jay', 80], ['viru', 85], ['basanti', 95], ['thakur', 83], ['sambha', 85]]

output = dict(my_list)
only_values = output.values()
unique_val = set(only_values)
sorted_val = sorted(unique_val)
second_largest_mark = sorted_val[-2]
print(second_largest_mark)

for ele in my_list:
    if ele[1] == second_largest_mark:  # ele[1] means 80..85..95
        print(ele[0])  # ele[1] 'Jay'..'viru'..'basanti'
