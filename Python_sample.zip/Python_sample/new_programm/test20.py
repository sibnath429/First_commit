"""
Write a program to display the words that are repeated more than or N times in the text.

"""

str1 = input("enter a string:")
n=int(input("enter a count"))
str1 = str1.split()
print(str1)

counts = {}

for word in str1:
    if word in counts:
        counts[word] += 1
    else:
        counts[word] = 1
print(counts)

empty_dict = {}
for key,val in counts.items():
    if val >= n:
        empty_dict[key] = val
print(empty_dict)


