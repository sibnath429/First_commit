"""
Write a python program for following req:
Input:- {'orange':'fruit','potato':'vegetable','banana':'fruit'}
Output:- {'fruit':['orange','banana'],'vegetable':['potato']}
"""

sample_dict = {'orange': 'fruit', 'potato': 'vegetable', 'banana': 'fruit'}

empty_dict = {}

for key, val in sample_dict.items():
    if val not in empty_dict:
        empty_dict[val] = [key]
    else:
        empty_dict[val].append(key)
print(empty_dict)
