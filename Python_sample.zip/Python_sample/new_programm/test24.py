"""
Input: "Sky is blue"
output: "blue is Sky"

"""

str1 = "Sky is blue"
mylist = str1.split()

str2 = mylist[::-1]
str3 = " ".join(str2)
print(str3)
