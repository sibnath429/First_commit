"""input : grades = [('elliot', 91),('neelam', 98),('bianca', 81),('elliot', 88),]

output : {'elliot': [91, 88], 'neelam': [98], 'bianca': [81]}"""

grades = [('elliot', 91),('neelam', 98),('bianca', 81),('elliot', 88),]


student_grades = {}
for name, grade in grades:
    if name not in student_grades:
        student_grades[name] = []
    student_grades[name].append(grade)
print(student_grades)


