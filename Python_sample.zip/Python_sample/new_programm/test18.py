"""
 PROBLEM:
Given a list of account ID numbers (integers) which contains duplicates , find the one unique integer. (the list is guaranteed to only have one unique (non-duplicated) integer.
** Do not use built-in Python functions or methods **

🔸Input:
id_list=[1,2,3,4,6,2,3,1,6]

🔸Output:
4
"""

id_list=[1,2,3,4,6,2,3,1,6]
empty_list = []
for temp in id_list:
    if temp not in empty_list:
        empty_list.append(temp)
    else:
        print("Unique ID {}".format(temp))