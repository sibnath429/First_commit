"""
prod = '''product_id,product_name,stock_remaining
1,pixel5,55
2,pixelbook,31
3,nesthub,2
'''
# output

# {'product_id': [1, 2, 3], 'product_name': ['pixel5,55', 'pixelbook', 'nesthub'], 'stock_remaining': [55, 31, 2]}

"""

prod = '''product_id,product_name,stock_remaining
1,pixel5,55
2,pixelbook,31
3,nesthub,2
3,nesthub,2'''


res = prod.split("\n")

print(res)

list_n = res[0].split(",")
print(list_n)

empty_dict = {}
for temp in list_n:
    empty_dict[temp] = []
print(empty_dict)


for i in range(1,len(res)):
    empty_dict['product_id'].append(res[i].split(",")[0])
    empty_dict['product_name'].append(res[i].split(",")[1])
    empty_dict['stock_remaining'].append(res[i].split(",")[2])
print(empty_dict)



