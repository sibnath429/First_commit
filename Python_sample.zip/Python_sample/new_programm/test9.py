"""
Sample Input
sample_dict = {'Harry': 42, 'Michael': 48, 'Josh': 57, 'John': 37}

Print only the items with an odd value of less than 45.

Expected Output
 'John': 37
"""

sample_dict = {'Harry': 42, 'Michael': 48, 'Josh': 57, 'John': 37}

for key, value in sample_dict.items():
    if value <= 45 and value % 2 != 0:
        print("key->value {}:{}".format(key, value))
