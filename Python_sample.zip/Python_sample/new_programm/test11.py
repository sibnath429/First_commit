"""
PROBLEM:
Given two strings, check to see if they are anagrams. An anagram is when
the two strings can be written using the exact same letters (so you can just rearrange
the letters to get a different phrase or word).
For example:
"a gentleman" is an anagram of "elegant man"
"Clint Eastwood" is an anagram of "old west action"

Note: Ignore spaces and capitalisation. So "two" is an anagram of "Tow" and "T w O" and "ow t".
Input:
str1="dog"
str2="god"

hints: len of strng1 and strng2 and same elements
"""
str1 = "a gentleman"
str2 = "ele gant man"
# convert both the strings into lowercase
str1 = str1.lower().replace(" ","")
str2 = str2.lower().replace(" ","")
print(str1)
# check if length is same
if len(str1) == len(str2):
    # sort the strings
    sorted_str1 = sorted(str1)
    sorted_str2 = sorted(str2)
    print(sorted_str1, sorted_str2)  # ['d', 'g', 'o'] ['d', 'g', 'o']
    # if sorted char arrays are same
    if sorted_str1 == sorted_str2:
        print(str1 + " and " + str2 + " are anagram.")
    else:
        print(str1 + " and " + str2 + " are not anagram.")

else:
    print(str1 + " and " + str2 + " are not anagram.")
