"""query = 'a=2&b=23&name=prakash'
output = {'a':'2','b':'23','name':'prakash'}"""

str1 = 'a=2&b=23&name=prakash'
var = str1.split('&')
print(var)  # ['a=2', 'b=23', 'name=prakash']

empty_list = []
for temp in var:
    res = temp.split("=")
    empty_list.append(res)

print(empty_list)  # [['a', '2'], ['b', '23'], ['name', 'prakash']]
conv_dict = dict(empty_list)
print(conv_dict)