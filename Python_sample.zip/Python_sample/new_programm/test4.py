"""Write a Python program to find the longest string in a given list of strings."""


def func(words):
    return max(words, key=len)


strs = ['cat', 'car', 'fear', 'center']
print("Original strings:")
print(strs)
print("Longest string of the said list of strings:")
print(func(strs))
