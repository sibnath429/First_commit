"""
Write a python program to sort characters and numbers so that first alphabets and then numbers are printed
Input : A7B1R3
Output: ABR137
"""

str1 = "A7B1R3"
alphabets = []
numbers = []

for ch in str1:
    if ch.isalpha():
        alphabets.append(ch)
    else:
        ch.isdigit()
        numbers.append(ch)

final_list= sorted(alphabets)+sorted(numbers)
output = ''.join(final_list)
print(output)


