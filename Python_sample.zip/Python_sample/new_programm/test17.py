"""
PROBLEM:
Implement a Fibonnaci Sequence with the help of recursion, Remember a fibonacci sequence: 0,1,1,2,3,5,8,13,21,...

⛔Note : There must be a recursive call for the function.

🔸Input:
N=10

🔸Output:
55
"""


def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)


print(fibonacci(4))
print(fibonacci(1))
print(fibonacci(2))
