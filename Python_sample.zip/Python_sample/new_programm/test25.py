"""
List = [1,3,4,3,3,3,5,5,5,6,7,7]
output = [1,4] #only one time occurrence
"""
List = [1, 3, 4, 3, 3, 3, 5, 5, 5, 6, 7, 7]

empty_list = []
for temp in List:
    if List.count(temp) == 1:
        empty_list.append(temp)
print(empty_list)
