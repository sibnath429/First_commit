"""
Input : 'a3b2c4' --> aaabbcccc

"""

str1 = 'a3b2c4'
output = ""
for ch in str1:
    if ch.isalpha():
        var = ch
    else:
        num = int(ch)
        final_output = output + (var * num)
        print(final_output, end='')