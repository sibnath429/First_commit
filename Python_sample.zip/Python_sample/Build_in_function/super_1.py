"""The Method Resolution Order (MRO) is the order in which methods should be inherited in the presence of multiple
inheritances. we can always view the MRO by using the __mro__ attribute. See the following example.
"""

# parent class one
class University:

   # constructor
 def __init__(self, Univeristy_name):

   # prints the name of university
   print(Univeristy_name, 'is the name of university.')

# child class
class Faculty(University):

   # constructor
 def __init__(self, name):
   print("Major subject is CS")

   # super function
   super().__init__(name)

 # child class
class Info(Faculty, University):

   # constructor
   def __init__(self):

       # using supper function
       super().__init__("UCA")

# mro
info = Info()
print(info.__mro__)