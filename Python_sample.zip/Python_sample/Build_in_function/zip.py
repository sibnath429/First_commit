"""Python zip function accepts iterable items and merges them into a single tuple. The resultant value is a zip
object that stores pairs of iterables. We can pass lists, tuples, sets, or dictionaries through the zip function. The
simple syntax of the python zip function is as follows:
"""

"""
zip(*iterables)
# or
zip(iterator_1, iterator_2, iterator_3 ...)
return as zip class-type object
"""

# creating lists
num = [1, 2, 3, 4, 5]
characters = ['a', 'b', 'c', 'd']
# applying python zip function
My_zipped_tuple = zip(num, characters)
# checking the type of zipped
print(type(My_zipped_tuple))

"""We can also pass multiple arguments to the zip function. Then the number of tuples returned by the function will 
be equal to the length of the provided iterable which has the smallest length.  Let us take an example and pass 
multiple arguments to the zip function. See the example below: """

# Creating list integer values
My_list1 = [1, 2, 3, 4, 5]
My_list2 = ['a', 'b', 'c']
My_list3 = ['Age', 'name', 'city', 'country']
# calling zip function with multiple arguments
My_zipped_variable = zip(My_list1, My_list2, My_list3)
# creating list of the zipped object
zipped_list = list(My_zipped_variable)
# printing
print(zipped_list)

