"""The strip() method removes any leading (spaces at the beginning) and trailing (spaces at the end) characters"""
"""When a developer wishes to remove characters or whitespaces from the beginning or end of a string, the Strip() 
function in Python comes in handy. """

# Python3 program to demonstrate the use of
# strip() method

string = """ geeks for geeks """

# prints the string without stripping
print(string)

# prints the string by removing leading and trailing whitespaces
print(string.strip())

# prints the string by removing geeks
print(string.strip(' geeks'))

""" prints the string after removing the from beginning and end"""
string = " the King has the largest army in the entire world the"
print(string.strip(" the"))
