"""Which subprocess module function should I use?
The functions run(), call(), check_call(), and check_output() are wrappers around the Popen class.
Using Popen directly gives more control over how the command is run,
and how its input and output streams are processed."""

"""
Use subprocess.call or subprocess.run to run the command described by args. 
Wait for command to complete, then return the returncode attribute.
Use subprocess.Popen with wait() to wait for the command to complete
"""
"""
subprocess.run():
The subprocess.run() function was added in Python 3.5
Wait for command to complete, then return a subprocess.CompletedProcess instance.
If capture_output is true, stdout and stderr will be captured.
When used, the internal Popen object is automatically created with stdout=PIPE and stderr=PIPE.
The stdout and stderr arguments may not be supplied at the same time as capture_output.
If you wish to capture and combine both streams into one, use stdout=PIPE and stderr=STDOUT instead of capture_output.
"""

import subprocess

# Define command as string and then split() into list format
cmd = 'ping -c2 google.c12om'.split()

# Check the list value of cmd
print('command in list format:',cmd)

sp = subprocess.run(cmd, shell=False, check=True, capture_output=True, text=True)
print("stdout: ", sp.stdout)
print("stderr: ", sp.stderr)

"""We can use the check=True keyword argument to 
subprocess.run to have an exception raised if the external program returns a non-zero exit code:"""
"""
capture_output is supported only with Python 3.7, if used with earlier version then you will get TypeError: __init__() got an unexpected keyword argument 'capture_output'. 
For older releases you can continue to use stdout=PIPE and stderr=PIPE
"""