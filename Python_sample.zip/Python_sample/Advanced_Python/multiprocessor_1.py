"""Multiprocessing in Python is a built-in package that allows the system to run multiple processes simultaneously.
It will enable the breaking of applications into smaller threads that can run independently. The operating system can
then allocate all these threads or processes to the processor to run them parallelly, thus improving the overall
performance and efficiency. """

"""Performing multiple operations for a single processor becomes challenging. As the number of processes keeps 
increasing, the processor will have to halt the current process and move to the next, to keep them going. Thus, 
it will have to interrupt each task, thereby hampering the performance. """

"""The Python multiprocessing module provides multiple classes that allow us to build parallel programs to implement 
multiprocessing in Python. It offers an easy-to-use API for dividing processes between many processors, thereby fully 
leveraging multiprocessing. It overcomes the limitations of Global Interpreter Lock (GIL) by using sub-processes 
instead of threads. The primary classes of the Python multiprocessing module are: 

Process
Queue
Lock"""

# importing the multiprocessing module
import multiprocessing


def print_cube(num):
    """
	function to print cube of given num
	"""
    print("Cube: {}".format(num * num * num))


def print_square(num):
    """
	function to print square of given num
	"""
    print("Square: {}".format(num * num))


if __name__ == "__main__":
    # creating processes
    p1 = multiprocessing.Process(target=print_square, args=(10,))
    p2 = multiprocessing.Process(target=print_cube, args=(10,))

    # starting process 1
    p1.start()
    # starting process 2
    p2.start()

    # wait until process 1 is finished
    p1.join()
    # wait until process 2 is finished
    p2.join()

    # both processes finished
    print("Done!")
