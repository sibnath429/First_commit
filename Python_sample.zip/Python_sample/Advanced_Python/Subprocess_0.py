"""The subprocess module gives the developer the ability to start processes or programs from Python. In other words,
you can start applications and pass arguments to them using the subprocess module.
Replace the os modules set of os.popen, os.spawn and os.system calls
"""

"""
Call():
The subprocess module provides a function named call. This function allows you to call another program, 
wait for the command to complete and then return the return code. It accepts one or more arguments as well as the 
following keyword arguments (with their defaults): stdin=None, stdout=None, stderr=None, shell=False. 

It supports the same arguments as the Popen() constructor, such as shell, executable, and cwd, but this time, 
your script will wait for the program to complete and populate the return code without the need to communicate()

it returns a code zero (0). This means that it completed successfully. If you receive anything except for a zero, 
then it usually means you have had some kind of error. """

"""when we'll be using os.system or subprocess?: 
In this python script we aim to get the list of failed services. 
In RHEL 7/8 we use "systemctl --failed" to get the list of failed services
If your requirement is just to execute a system command then you can just use os.system(your_command) 
but here since we want to manipulate the output, we are using python subprocess"""

import subprocess
code = subprocess.call("notepad.exe")
if code == 0:
    print("Success!")
else:
    print("Error!")
"Success!"

"""The Popen class executes a child program in a new process. Unlike the call method, it does not wait for the called 
process to end unless you tell it to using by using the wait method. """


""" Another example"""

import subprocess

# Define command as string and then split() into list format
cmd = 'ip link show eth0'.split()

# Check the list value of cmd
print('command in list format:',cmd)

# Open the /tmp/dataFile and use "w" to write into the file
myfile = open("/tmp/dataFile", "w")

# Use shell=False to execute the command
is_eth0_present = subprocess.call(cmd, shell=False, stdout=myfile, stderr=subprocess.STDOUT)

if is_eth0_present == 0:
    print('Yes, eth0 is available on this server')
else:
    print('No, eth0 is not available on this server')

myfile.close()