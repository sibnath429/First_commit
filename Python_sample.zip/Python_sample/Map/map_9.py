"""
Write a Python program to add three given lists using Python map and lambda.

Original list:
[1, 2, 3]
[4, 5, 6]
[7, 8, 9]

New list after adding above three lists:
[12, 15, 18]

"""

nums1 = [1, 2, 3]
nums2 = [4, 5, 6]
nums3 = [7, 8, 9]
print("Original list: {} {} {}".format(nums1,nums2,nums3))
result = list(map(lambda x, y, z: x + y + z, nums1, nums2, nums3))
print("\nNew list after adding above three lists: {}".format(result))
