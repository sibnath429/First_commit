"""
Convert a list of integers, tuple of integers in a list of strings"""
"""
Original list and tuple:
[1, 2, 3, 4]
(0, 1, 2, 3)

List of strings:
['1', '2', '3', '4']

Tuple of strings:
('0', '1', '2', '3')
"""

original_list = [1, 2, 3, 4]
original_tuple = (0, 1, 2, 3)

print("original list {}".format(original_list))
res = list(map(str, original_list))
print("Modified list {}".format(res))

print("original tuple {}".format(original_tuple))
res = tuple(map(str, original_tuple))
print("Modified tuple {}".format(res))
