"""Write a Python program to convert a given list of strings into list of lists using map function"""

"""
Original list of strings:
['Red', 'Green', 'Black', 'Orange']

Convert the said list of strings into list of lists:
[['R', 'e', 'd'], ['G', 'r', 'e', 'e', 'n'], ['B', 'l', 'a', 'c', 'k'], ['O', 'r', 'a', 'n', 'g', 'e']]
"""

colors = ["Red", "Green", "Black", "Orange"]
print('Original list of strings: {}'.format(colors))
print("\nConvert the said list of strings into list of lists:")
result = list(map(list, colors))
print("\nConverted the said list of strings into list of lists:{}".format(result))

