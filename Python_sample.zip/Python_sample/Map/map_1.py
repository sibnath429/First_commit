"""
Write a Python program to convert a given list of tuples to a list of strings using map function.

test_list = [('G', 'E', 'E', 'K', 'S'), ('F', 'O', 'R'),
             ('G', 'E', 'E', 'K', 'S')]

The list after conversion to list of string is = ['GEEKS', 'FOR', 'GEEKS']

List in Tuple -> List in String
"""

# initializing list
test_list = [('G', 'E', 'E', 'K', 'S'), ('F', 'O', 'R'),
             ('G', 'E', 'E', 'K', 'S')]

# printing the original list
print("The original list is {}: ".format(test_list))

# using list comprehension + join()
# conversion of list of tuple to list of list
res = [''.join(i) for i in test_list]

# printing result
print("The list after conversion to list of string is: {} ".format(res))

""" Using map() function"""

result = list(map(''.join, test_list))

print("Using Map function list of string is: {} ".format(result))