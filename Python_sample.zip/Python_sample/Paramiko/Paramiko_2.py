"""For uploading and downloading file """

import paramiko
import time

# Create object of SSHClient and
# connecting to SSH
ssh = paramiko.SSHClient()

# Adding new host key to the local
# HostKeys object(in case of missing)
# AutoAddPolicy for missing host key to be set before connection setup.
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

ssh.connect('10.224.77.58', username='root', password='password', timeout=3)

# Execute command on SSH terminal
# using exec_command
""" To upload file"""
ftp_client = ssh.open_sftp()
ftp_client.put("paramiko_1.py", "root")
ftp_client.close()

""" To download a file"""

ftp_client.get("root/paramiko_1.py","C:\\Automation\\dmidecode")
ftp_client.close()
