"""Paramiko is a Python library that makes a connection with a remote device through SSh. Paramiko is using SSH2 as a
replacement for SSL to make a secure connection between two devices. It also supports the SFTP client and server
model. """

"""
ssh <ip address> or <hostname>

192.168.0.2 "free -m" <to execute any command remotely>

upload or download any file without login

**There are two ways to connect the Host machine
1. username and password
    ssh centos@<ip address or hostname>
    password
2. ssh -i <key> centos@<ip address or hostname> *Using crypto key*

3.# Execute command on SSH terminal
# using exec_command
stdin, stdout, stderr = ssh.exec_command('show ip interface brief')
stdin :  when your command require some input
stdout : when your command require some output
stderr: when your expect some error.
            
"""
import paramiko
import time

# Create object of SSHClient and
# connecting to SSH
ssh = paramiko.SSHClient()

# Adding new host key to the local
# HostKeys object(in case of missing)
# AutoAddPolicy for missing host key to be set before connection setup.
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

ssh.connect('10.224.77.58', username='root',password='password', timeout=3)

# Execute command on SSH terminal
# using exec_command
stdin, stdout, stderr = ssh.exec_command('free -m')
time.sleep(5) # to give enough time
print(stdout.readlines())
ssh.close()
"""
local machine --> ssh --> remote machine
first time --> ssh --> remote machine
Machine doesn't trust the remote server so , 
error: paramiko.ssh_exception.SSHException: Server '10.224.77.58' not found in known_hosts
In order to trust host/client trust we need to set AutoAddPolicy():
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
"""
"""** In cloud environment instead of password we nned to send key_filename of password **
ssh.connect('10.224.xx.xx', username='ec2-user',key_filename ="/home/usr", timeout=3)
"""