from pyparsing import nums


def firstn(n):
    num_list = []
    num = 0
    while num < n:
        num_list.append(num)
        num += 1
    return num_list

def firstn_generator(n):
    num = 0
    while num < n:
        yield num
        num += 1


print(firstn(10))
print(list(firstn_generator(10)))
