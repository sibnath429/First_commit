# checks if list still
# contains any element
a = [1, 2, 3, 4]

while a:
    print(a.pop())

print(a)
