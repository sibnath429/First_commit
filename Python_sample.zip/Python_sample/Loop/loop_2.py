# python code to demonstrate working of enumerate()

for key, value in enumerate(['Geeks', 'for', 'Geeks',
                             'is', 'the', 'Best',
                             'Coding', 'Platform']):
    print(value, end=' ')
