"""Way 1: Using enumerate():  enumerate() is used to loop through the containers printing the index number along with
the value present in that particular index. """

# python code to demonstrate working of enumerate()

for key, value in enumerate(['The', 'Big', 'Bang', 'Theory']):
	print(key, value)

