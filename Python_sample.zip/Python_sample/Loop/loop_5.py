# python code to demonstrate working of sorted()

# initializing list
basket = ['guave', 'orange', 'apple', 'pear',
          'guava', 'banana', 'grape']

# using sorted() and set() to print the list
# in sorted order
for fruit in sorted(set(basket)):
    print(fruit)


"""Reverse range"""
# python code to demonstrate working of reversed()

# using reversed() to print in reverse order
for i in reversed(range(1, 10, 3)):
    print(i)
