# Python program to get current time

# importing the datetime class
# from datetime module
from datetime import datetime

# calling the now() function
obj_now = datetime.now()

# formatting the time
# current_time = obj_now.strftime("%H:%M:%S")
print("Current time is:", obj_now)