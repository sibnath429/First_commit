# Python program to
# print today's year, month and day

# importing the date class datetime module
import time
from datetime import datetime
while(True):

    # creating the date object of today's date
    current_date = datetime.today()

    # printing the current date
    print("Current date: ", current_date)

    # extracting the current year, month and day
    print("Current year:", current_date.year)
    print("Current month:", current_date.month)
    print("Current day:", current_date.day)
    print("Current hour =", current_date.hour)
    print("Current minute =", current_date.minute)
    print("Current second =", current_date.second)
    print("Current microsecond =", current_date.microsecond)
    time.sleep(10)